# utils/constants.py

# Service Request Statuses
PENDING_STATUS = 'pending'
IN_PROGRESS_STATUS = 'in_progress'
RESOLVED_STATUS = 'resolved'
CLOSED_STATUS = 'closed'

# Service Request Priorities
LOW_PRIORITY = 'low'
MEDIUM_PRIORITY = 'medium'
HIGH_PRIORITY = 'high'
URGENT_PRIORITY = 'urgent'

# Common Messages
SUCCESS_MESSAGE = "Action completed successfully."
ERROR_MESSAGE = "An error occurred. Please try again."

# File Upload Paths
SERVICE_REQUEST_ATTACHMENTS_PATH = 'service_requests/'

# Default Pagination Settings
DEFAULT_PAGE_SIZE = 10
