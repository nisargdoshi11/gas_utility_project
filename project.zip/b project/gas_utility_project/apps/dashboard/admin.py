# apps/dashboard/admin.py
from django.contrib import admin
# No models to register in admin currently