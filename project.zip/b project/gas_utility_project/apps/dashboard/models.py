# apps/dashboard/models.py
from django.db import models

# Currently, no models are needed for the dashboard app as it's primarily for views
# This file can remain empty or be used for future dashboard-specific models